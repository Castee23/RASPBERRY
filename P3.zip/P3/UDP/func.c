int fun(int b){
    int a=b*2;
    return a;
}
