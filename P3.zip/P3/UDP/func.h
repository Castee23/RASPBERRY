#ifndef __FUNC_H
#define __FUNC_H
    int fun(int);
#endif
