#include "func.h"
#include <iostream>
int main(void){
    int b=2;
    std::cout<<"A is: "<< fun(b) << std::endl;
}
